﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Talent.Common.Services
{
    public interface IServiceHost
    {
    }
}
